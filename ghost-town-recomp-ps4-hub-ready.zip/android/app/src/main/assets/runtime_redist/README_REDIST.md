# Runtime & Common Redistributables (Android ARM64 / Vulkan)

Direktori ini menyimpan berkas konfigurasi dan pustaka pendukung runtime untuk menjalankan game Unity PC pada Android:

1. `mono_bcl/`:
   - Menyimpan Base Class Library (.NET / Mono) seperti `mscorlib.dll`, `System.dll`, dan `System.Core.dll`.
   - Saat Anda mengimpor salah satu game (`Overcooked_Data`, `Overcooked2_Data`, `MovingOut_Data`, atau `MovingOut2_Data`), `RuntimeRedistManager` otomatis menyalin pustaka `.NET` BCL tersebut ke folder ini agar dapat digunakan bersama.
   - Anda juga dapat menyalin manual `mscorlib.dll`, `System.dll`, dan `System.Core.dll` dari folder `*_Data/Managed/` instalasi PC Anda ke `/sdcard/Android/data/com.overcookedrecomp.app/files/runtime_redist/mono_bcl/`.

2. `win32_shims/`:
   - `vcredist_posix_map.cfg` memetakan pustaka Visual C++ Redistributable (`msvcp140.dll`, `vcruntime140.dll`), DirectX (`d3d11.dll`, `dxgi.dll`), dan XInput (`xinput1_3.dll`) ke lapisan native Android NDK (`VulkanContext`, `InputMapper`, dan `AAudioMixer`).
