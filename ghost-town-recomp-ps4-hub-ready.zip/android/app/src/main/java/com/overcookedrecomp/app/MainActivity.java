package com.overcookedrecomp.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.overcookedrecomp.app.compiler.core.RuntimeRedistManager;
import com.overcookedrecomp.app.input.GamepadManager;
import com.overcookedrecomp.app.input.VirtualGamepadOverlay;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    public static final String EXTRA_AUTO_LAUNCH_GAME_ID = "EXTRA_AUTO_LAUNCH_GAME_ID";
    private static final String TAG = "OvercookedRecomp";
    private static boolean nativeLoaded = false;
    private static String nativeLoadError = null;

    static {
        try {
            System.loadLibrary("overcooked_native");
            nativeLoaded = true;
            Log.i(TAG, "Pustaka native overcooked_native berhasil dimuat.");
        } catch (Throwable t) {
            nativeLoaded = false;
            nativeLoadError = t.getMessage();
            Log.e(TAG, "Gagal memuat pustaka native overcooked_native: " + t.getMessage(), t);
        }
    }

    private static final class GameTileItem {
        final GameStorageVerifier.GameTitle title;
        final String displayTitle;
        final String subtitle;
        final String badgeText;
        final int iconRes;
        final String accentColor;
        final String bgTintColor;

        GameStorageVerifier.VerificationResult verificationResult;
        LinearLayout cardView;
        TextView statusBadge;
        TextView actionHint;

        GameTileItem(GameStorageVerifier.GameTitle title, String displayTitle, String subtitle,
                     String badgeText, int iconRes, String accentColor, String bgTintColor) {
            this.title = title;
            this.displayTitle = displayTitle;
            this.subtitle = subtitle;
            this.badgeText = badgeText;
            this.iconRes = iconRes;
            this.accentColor = accentColor;
            this.bgTintColor = bgTintColor;
        }
    }

    private SurfaceView gameSurfaceView;
    private FrameLayout rootLayout;
    private LinearLayout hubOverlayView;
    private HorizontalScrollView gameCarouselScroll;
    private LinearLayout gameCarouselRow;

    private TextView heroTitleText;
    private TextView heroSubtitleText;
    private TextView heroRuntimeText;
    private TextView redistStatusText;
    private TextView importProgressText;
    private ProgressBar importProgressBar;

    private GamepadManager gamepadManager;
    private VirtualGamepadOverlay virtualOverlay;
    private boolean virtualControlsEnabled = true;
    private boolean engineInitialized = false;

    private final List<GameTileItem> gameTiles = new ArrayList<>();
    private int focusedIndex = 0;
    private int pendingAutoLaunchId = -1;
    private GameStorageVerifier.GameTitle pendingImportTitle = GameStorageVerifier.GameTitle.OVERCOOKED_1;

    private final ActivityResultLauncher<String[]> openZipLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) handleImportZipUri(uri);
            });

    private final ActivityResultLauncher<Uri> openFolderLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri != null) handleImportFolderUri(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (getIntent() != null) {
            pendingAutoLaunchId = getIntent().getIntExtra(EXTRA_AUTO_LAUNCH_GAME_ID, -1);
        }

        // 1. Siapkan lingkungan .NET/Mono BCL & Win32/Vulkan Redistributable Shims
        RuntimeRedistManager.RedistStatus redistStatus = RuntimeRedistManager.INSTANCE.ensureRedistEnvironment(this);

        // 2. Deteksi spesifikasi layar perangkat
        detectAndApplyDeviceDisplaySettings();

        // 3. Inisialisasi daftar 4 game
        initGameTilesData();

        // 4. Susun Root View (SurfaceView Vulkan di belakang, PS4/GameHub UI di depan)
        rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        gameSurfaceView = new SurfaceView(this);
        gameSurfaceView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        gameSurfaceView.getHolder().addCallback(this);
        rootLayout.addView(gameSurfaceView);

        // 5. Gamepad Fisik (DS4 / Xbox)
        gamepadManager = new GamepadManager(this);
        gamepadManager.setInputCallback(new GamepadManager.InputCallback() {
            @Override
            public void onAxisEvent(int deviceId, float lx, float ly, float rx, float ry, float hatX, float hatY) {
                if (nativeLoaded && hubOverlayView.getVisibility() != View.VISIBLE) {
                    try {
                        nativeOnGamepadAxis(deviceId, lx, ly, rx, ry, hatX, hatY);
                    } catch (Throwable ignored) {}
                }
            }

            @Override
            public void onButtonEvent(int deviceId, int keyCode, boolean pressed) {
                if (hubOverlayView != null && hubOverlayView.getVisibility() == View.VISIBLE) {
                    if (pressed) {
                        runOnUiThread(() -> handleHubGamepadKey(keyCode));
                    }
                    return;
                }
                if (nativeLoaded) {
                    try {
                        nativeOnGamepadButton(deviceId, keyCode, pressed);
                    } catch (Throwable ignored) {}
                }
            }
        });

        // 6. Virtual On-Screen Touch Gamepad
        virtualOverlay = new VirtualGamepadOverlay(this);
        virtualOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        virtualOverlay.setInputListener(new VirtualGamepadOverlay.VirtualInputListener() {
            @Override
            public void onVirtualAxis(float lx, float ly) {
                if (nativeLoaded) {
                    try {
                        nativeOnGamepadAxis(999, lx, ly, 0f, 0f, 0f, 0f);
                    } catch (Throwable ignored) {}
                }
            }

            @Override
            public void onVirtualButton(int keyCode, boolean pressed) {
                if (nativeLoaded) {
                    try {
                        nativeOnGamepadButton(999, keyCode, pressed);
                    } catch (Throwable ignored) {}
                }
            }

            @Override
            public void onToggleMenuRequested() {
                toggleHubOverlay();
            }
        });
        rootLayout.addView(virtualOverlay);

        // 7. PS4 / GameHub Launcher Overlay
        hubOverlayView = createGameHubLayout(redistStatus);
        rootLayout.addView(hubOverlayView);

        // 8. Tombol Menu Mengambang saat in-game
        Button menuBtn = createFloatingMenuButton();
        rootLayout.addView(menuBtn);

        setContentView(rootLayout);

        if (!nativeLoaded) {
            new AlertDialog.Builder(this)
                    .setTitle("Peringatan Pustaka Native")
                    .setMessage("Pustaka C++ (" + nativeLoadError + ") gagal dimuat. Pastikan perangkat menggunakan arsitektur arm64-v8a.")
                    .setPositiveButton("OK", null)
                    .show();
        }

        selectGameTile(0, false);
        refreshInstalledGamesStatus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.hasExtra(EXTRA_AUTO_LAUNCH_GAME_ID)) {
            pendingAutoLaunchId = intent.getIntExtra(EXTRA_AUTO_LAUNCH_GAME_ID, -1);
            refreshInstalledGamesStatus();
        }
    }

    private void initGameTilesData() {
        gameTiles.clear();
        gameTiles.add(new GameTileItem(
                GameStorageVerifier.GameTitle.OVERCOOKED_1,
                "Overcooked!",
                "Unity 5 Mono CIL (.NET) • Classic Co-op Kitchen Chaos",
                "MONO / .NET",
                R.drawable.ic_overcooked,
                "#FF9F1C",
                "#F217120A"
        ));
        gameTiles.add(new GameTileItem(
                GameStorageVerifier.GameTitle.OVERCOOKED_2,
                "Overcooked! 2",
                "Unity Engine • Recipe Sync & Ingredient Throw Mechanic",
                "MONO / IL2CPP",
                R.drawable.ic_overcooked,
                "#E71D36",
                "#F21A0B10"
        ));
        gameTiles.add(new GameTileItem(
                GameStorageVerifier.GameTitle.MOVING_OUT,
                "Moving Out",
                "SMG Studio / Ghost Town • Furniture Physics & Delivery Truck",
                "IL2CPP / MONO",
                R.drawable.ic_moving_out,
                "#00A8E8",
                "#F2081622"
        ));
        gameTiles.add(new GameTileItem(
                GameStorageVerifier.GameTitle.MOVING_OUT_2,
                "Moving Out 2",
                "Unity 2021.3+ • Multiverse Delivery & Arcade Joint Physics",
                "IL2CPP AOT",
                R.drawable.ic_moving_out,
                "#06D6A0",
                "#F2071B17"
        ));
    }

    private LinearLayout createGameHubLayout(RuntimeRedistManager.RedistStatus redistStatus) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setPadding(44, 26, 44, 22);
        root.setBackgroundColor(Color.parseColor("#F20B1220"));

        // === TOP STATUS BAR (PS4 / GameHub Header) ===
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout brandBox = new LinearLayout(this);
        brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView hubBrand = new TextView(this);
        hubBrand.setText("GHOST TOWN GAMEHUB");
        hubBrand.setTextSize(18);
        hubBrand.setTextColor(Color.WHITE);
        hubBrand.setTypeface(null, Typeface.BOLD);
        brandBox.addView(hubBrand);

        redistStatusText = new TextView(this);
        redistStatusText.setText("Runtime & Redist: " + redistStatus.getSummary());
        redistStatusText.setTextSize(11);
        redistStatusText.setTextColor(redistStatus.getReady() ? Color.parseColor("#06D6A0") : Color.parseColor("#FFD166"));
        brandBox.addView(redistStatusText);
        topBar.addView(brandBox);

        Button scanBtn = createTopPillButton("Scan Download", "#1E293B", "#38BDF8");
        scanBtn.setOnClickListener(v -> scanDownloadFolder());
        topBar.addView(scanBtn);

        Button virtualBtn = createTopPillButton("Touch: ON", "#1E293B", "#06D6A0");
        virtualBtn.setOnClickListener(v -> {
            virtualControlsEnabled = !virtualControlsEnabled;
            if (virtualOverlay != null) {
                virtualOverlay.setVisibility(virtualControlsEnabled ? View.VISIBLE : View.GONE);
            }
            virtualBtn.setText(virtualControlsEnabled ? "Touch: ON" : "Touch: OFF");
        });
        LinearLayout.LayoutParams vLp = (LinearLayout.LayoutParams) virtualBtn.getLayoutParams();
        vLp.setMarginStart(12);
        topBar.addView(virtualBtn);

        Button gfxBtn = createTopPillButton("Grafik & Vulkan", "#1E293B", "#F59E0B");
        gfxBtn.setOnClickListener(v -> showGraphicsSettingsDialog());
        LinearLayout.LayoutParams gLp = (LinearLayout.LayoutParams) gfxBtn.getLayoutParams();
        gLp.setMarginStart(12);
        topBar.addView(gfxBtn);

        root.addView(topBar);

        // === PROGRESS BAR IMPOR ===
        importProgressText = new TextView(this);
        importProgressText.setTextSize(12);
        importProgressText.setTextColor(Color.parseColor("#38BDF8"));
        importProgressText.setPadding(0, 6, 0, 2);
        importProgressText.setVisibility(View.GONE);
        root.addView(importProgressText);

        importProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        importProgressBar.setIndeterminate(true);
        importProgressBar.setVisibility(View.GONE);
        root.addView(importProgressBar);

        // === PS4 XMB HORIZONTAL GAME ICON RIBBON (4 GAME TILES) ===
        gameCarouselScroll = new HorizontalScrollView(this);
        gameCarouselScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.setMargins(0, 14, 0, 10);
        gameCarouselScroll.setLayoutParams(scrollLp);

        gameCarouselRow = new LinearLayout(this);
        gameCarouselRow.setOrientation(LinearLayout.HORIZONTAL);
        gameCarouselRow.setGravity(Gravity.CENTER_VERTICAL);
        gameCarouselRow.setPadding(8, 10, 8, 10);

        for (int i = 0; i < gameTiles.size(); i++) {
            final int index = i;
            GameTileItem item = gameTiles.get(i);
            View tileView = createPs4GameTileView(item, index);
            gameCarouselRow.addView(tileView);
        }

        gameCarouselScroll.addView(gameCarouselRow);
        root.addView(gameCarouselScroll);

        // === BOTTOM HERO DETAIL PANEL ===
        LinearLayout bottomInfoPanel = new LinearLayout(this);
        bottomInfoPanel.setOrientation(LinearLayout.HORIZONTAL);
        bottomInfoPanel.setGravity(Gravity.CENTER_VERTICAL);
        bottomInfoPanel.setPadding(24, 12, 24, 12);
        bottomInfoPanel.setBackground(createRoundedBox("#141D2F", "#263552", 18, 2));

        LinearLayout infoLeft = new LinearLayout(this);
        infoLeft.setOrientation(LinearLayout.VERTICAL);
        infoLeft.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        heroTitleText = new TextView(this);
        heroTitleText.setTextSize(21);
        heroTitleText.setTextColor(Color.WHITE);
        heroTitleText.setTypeface(null, Typeface.BOLD);
        infoLeft.addView(heroTitleText);

        heroSubtitleText = new TextView(this);
        heroSubtitleText.setTextSize(12);
        heroSubtitleText.setTextColor(Color.parseColor("#94A3B8"));
        infoLeft.addView(heroSubtitleText);

        heroRuntimeText = new TextView(this);
        heroRuntimeText.setTextSize(12);
        heroRuntimeText.setTypeface(null, Typeface.BOLD);
        heroRuntimeText.setPadding(0, 3, 0, 0);
        infoLeft.addView(heroRuntimeText);

        bottomInfoPanel.addView(infoLeft);

        TextView controllerHint = new TextView(this);
        controllerHint.setText("Tap Icon Game untuk Main  •  [◀/▶] Pilih  •  [✕ / A] Play  •  [△ / Y] Impor ZIP");
        controllerHint.setTextSize(11);
        controllerHint.setTextColor(Color.parseColor("#CBD5E1"));
        bottomInfoPanel.addView(controllerHint);

        root.addView(bottomInfoPanel);
        return root;
    }

    private View createPs4GameTileView(GameTileItem item, int index) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(20, 16, 20, 14);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(360, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(14, 8, 14, 8);
        card.setLayoutParams(cardLp);
        card.setBackground(createRoundedBox("#162033", "#2A3954", 24, 3));

        TextView runtimeBadge = new TextView(this);
        runtimeBadge.setText(item.badgeText);
        runtimeBadge.setTextSize(10);
        runtimeBadge.setTypeface(null, Typeface.BOLD);
        runtimeBadge.setTextColor(Color.parseColor(item.accentColor));
        runtimeBadge.setPadding(12, 4, 12, 4);
        runtimeBadge.setBackground(createRoundedBox("#0B1220", item.accentColor, 10, 1));
        card.addView(runtimeBadge);

        ImageView iconView = new ImageView(this);
        iconView.setImageResource(item.iconRes);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(140, 140);
        iconLp.setMargins(0, 12, 0, 8);
        iconView.setLayoutParams(iconLp);
        card.addView(iconView);

        TextView nameView = new TextView(this);
        nameView.setText(item.displayTitle);
        nameView.setTextSize(17);
        nameView.setTextColor(Color.WHITE);
        nameView.setTypeface(null, Typeface.BOLD);
        nameView.setGravity(Gravity.CENTER);
        card.addView(nameView);

        TextView statusView = new TextView(this);
        statusView.setText("Memeriksa...");
        statusView.setTextSize(11);
        statusView.setTypeface(null, Typeface.BOLD);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, 3, 0, 5);
        card.addView(statusView);

        TextView playLabel = new TextView(this);
        playLabel.setText("▶ TAP ICON UNTUK MAIN");
        playLabel.setTextSize(11);
        playLabel.setTypeface(null, Typeface.BOLD);
        playLabel.setTextColor(Color.WHITE);
        playLabel.setGravity(Gravity.CENTER);
        playLabel.setPadding(16, 8, 16, 8);
        playLabel.setBackground(createRoundedBox(item.accentColor, item.accentColor, 12, 0));
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        playLp.setMargins(0, 4, 0, 10);
        playLabel.setLayoutParams(playLp);
        card.addView(playLabel);

        LinearLayout importRow = new LinearLayout(this);
        importRow.setOrientation(LinearLayout.HORIZONTAL);
        importRow.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button zipBtn = new Button(this);
        zipBtn.setText("ZIP PC");
        zipBtn.setTextSize(10);
        zipBtn.setTextColor(Color.parseColor("#E2E8F0"));
        zipBtn.setBackground(createRoundedBox("#0F172A", "#334155", 10, 1));
        LinearLayout.LayoutParams zLp = new LinearLayout.LayoutParams(0, 64, 1f);
        zLp.setMarginEnd(6);
        zipBtn.setLayoutParams(zLp);
        zipBtn.setOnClickListener(v -> {
            selectGameTile(index, false);
            pendingImportTitle = item.title;
            openZipLauncher.launch(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"});
        });
        importRow.addView(zipBtn);

        Button folderBtn = new Button(this);
        folderBtn.setText("Folder");
        folderBtn.setTextSize(10);
        folderBtn.setTextColor(Color.parseColor("#E2E8F0"));
        folderBtn.setBackground(createRoundedBox("#0F172A", "#334155", 10, 1));
        folderBtn.setLayoutParams(new LinearLayout.LayoutParams(0, 64, 1f));
        folderBtn.setOnClickListener(v -> {
            selectGameTile(index, false);
            pendingImportTitle = item.title;
            openFolderLauncher.launch(null);
        });
        importRow.addView(folderBtn);

        card.addView(importRow);

        card.setOnClickListener(v -> {
            if (focusedIndex != index) {
                selectGameTile(index, true);
            } else {
                triggerTilePrimaryAction(item);
            }
        });

        item.cardView = card;
        item.statusBadge = statusView;
        item.actionHint = playLabel;
        return card;
    }

    private void selectGameTile(int index, boolean smoothScroll) {
        if (index < 0 || index >= gameTiles.size()) return;
        focusedIndex = index;

        for (int i = 0; i < gameTiles.size(); i++) {
            GameTileItem tile = gameTiles.get(i);
            boolean isFocused = (i == focusedIndex);
            if (tile.cardView != null) {
                tile.cardView.animate()
                        .scaleX(isFocused ? 1.07f : 0.94f)
                        .scaleY(isFocused ? 1.07f : 0.94f)
                        .alpha(isFocused ? 1.0f : 0.72f)
                        .setDuration(160)
                        .start();
                tile.cardView.setBackground(createRoundedBox(
                        isFocused ? "#1E293B" : "#111827",
                        isFocused ? tile.accentColor : "#263248",
                        24,
                        isFocused ? 4 : 2
                ));
            }
        }

        GameTileItem selected = gameTiles.get(focusedIndex);
        if (hubOverlayView != null) {
            hubOverlayView.setBackgroundColor(Color.parseColor(selected.bgTintColor));
        }
        if (heroTitleText != null) {
            heroTitleText.setText(selected.displayTitle);
            heroTitleText.setTextColor(Color.parseColor(selected.accentColor));
        }
        if (heroSubtitleText != null) {
            heroSubtitleText.setText(selected.subtitle);
        }
        if (heroRuntimeText != null) {
            if (selected.verificationResult != null && selected.verificationResult.valid) {
                heroRuntimeText.setText("● SIAP DIMAINKAN (" + selected.verificationResult.backendType.name() + ") — Klik Icon Game untuk Mulai");
                heroRuntimeText.setTextColor(Color.parseColor("#06D6A0"));
            } else {
                heroRuntimeText.setText("○ FOLDER DATA BELUM TERPASANG (" + selected.title.defaultFolderName + ") — Klik Icon Game untuk Impor");
                heroRuntimeText.setTextColor(Color.parseColor("#F87171"));
            }
        }

        if (smoothScroll && gameCarouselScroll != null && selected.cardView != null) {
            int scrollX = selected.cardView.getLeft() - (gameCarouselScroll.getWidth() / 2) + (selected.cardView.getWidth() / 2);
            gameCarouselScroll.smoothScrollTo(Math.max(0, scrollX), 0);
        }
    }

    private void triggerTilePrimaryAction(GameTileItem item) {
        if (item.verificationResult != null && item.verificationResult.valid) {
            launchGame(item.verificationResult);
        } else {
            pendingImportTitle = item.title;
            new AlertDialog.Builder(this)
                    .setTitle(item.displayTitle + " Belum Terpasang")
                    .setMessage("Pilih sumber berkas PC '" + item.title.defaultFolderName + "' untuk mulai bermain:")
                    .setPositiveButton("Impor File .ZIP PC", (d, w) ->
                            openZipLauncher.launch(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"}))
                    .setNegativeButton("Pilih Folder PC", (d, w) ->
                            openFolderLauncher.launch(null))
                    .setNeutralButton("Batal", null)
                    .show();
        }
    }

    private void handleHubGamepadKey(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                selectGameTile((focusedIndex - 1 + gameTiles.size()) % gameTiles.size(), true);
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                selectGameTile((focusedIndex + 1) % gameTiles.size(), true);
                break;
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_DPAD_CENTER:
                triggerTilePrimaryAction(gameTiles.get(focusedIndex));
                break;
            case KeyEvent.KEYCODE_BUTTON_Y:
                pendingImportTitle = gameTiles.get(focusedIndex).title;
                openZipLauncher.launch(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"});
                break;
        }
    }

    private void refreshInstalledGamesStatus() {
        File extDir = getExternalFilesDir(null);
        if (extDir == null) return;

        new Thread(() -> {
            RuntimeRedistManager.RedistStatus redist = RuntimeRedistManager.INSTANCE.ensureRedistEnvironment(this);
            List<GameStorageVerifier.VerificationResult> detected = GameStorageVerifier.detectInstalledGames(extDir);
            Map<GameStorageVerifier.GameTitle, GameStorageVerifier.VerificationResult> resultMap = new HashMap<>();
            for (GameStorageVerifier.VerificationResult res : detected) {
                resultMap.put(res.gameTitle, res);
            }

            runOnUiThread(() -> {
                if (redistStatusText != null) {
                    redistStatusText.setText("Runtime & Redist: " + redist.getSummary());
                }
                GameStorageVerifier.VerificationResult autoLaunchTarget = null;
                for (int i = 0; i < gameTiles.size(); i++) {
                    GameTileItem tile = gameTiles.get(i);
                    GameStorageVerifier.VerificationResult res = resultMap.get(tile.title);
                    tile.verificationResult = res;
                    if (res != null && res.valid) {
                        tile.statusBadge.setText("● SIAP (" + res.backendType.name() + ")");
                        tile.statusBadge.setTextColor(Color.parseColor("#06D6A0"));
                        tile.actionHint.setText("▶ PLAY " + tile.displayTitle.toUpperCase());
                        tile.actionHint.setBackground(createRoundedBox(tile.accentColor, tile.accentColor, 12, 0));
                        if (pendingAutoLaunchId == tile.title.id) {
                            focusedIndex = i;
                            autoLaunchTarget = res;
                        }
                    } else {
                        tile.statusBadge.setText("○ BUTUH " + tile.title.defaultFolderName);
                        tile.statusBadge.setTextColor(Color.parseColor("#F87171"));
                        tile.actionHint.setText("＋ IMPOR DATA GAME");
                        tile.actionHint.setBackground(createRoundedBox("#334155", "#475569", 12, 0));
                    }
                }
                selectGameTile(focusedIndex, false);
                if (autoLaunchTarget != null) {
                    pendingAutoLaunchId = -1;
                    launchGame(autoLaunchTarget);
                }
            });
        }).start();
    }

    private void launchGame(GameStorageVerifier.VerificationResult game) {
        if (!nativeLoaded) {
            Toast.makeText(this, "Pustaka native C++ belum siap.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (hubOverlayView != null) {
            hubOverlayView.setVisibility(View.GONE);
        }
        try {
            Log.i(TAG, "Meluncurkan " + game.gameTitle.displayName + " dari: " + game.dataDir.getAbsolutePath());
            nativeInitEngine(game.dataDir.getAbsolutePath(), game.backendType.ordinal(), game.gameTitle.id);
            engineInitialized = true;
            Toast.makeText(this, "Memulai " + game.gameTitle.displayName + " (Vulkan Engine)...", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Log.e(TAG, "Gagal meluncurkan engine: " + t.getMessage(), t);
            Toast.makeText(this, "Gagal memulai engine: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void toggleHubOverlay() {
        if (hubOverlayView == null) return;
        if (hubOverlayView.getVisibility() == View.VISIBLE) {
            hubOverlayView.setVisibility(View.GONE);
        } else {
            refreshInstalledGamesStatus();
            hubOverlayView.setVisibility(View.VISIBLE);
        }
    }

    private Button createTopPillButton(String text, String bgHex, String strokeHex) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(11);
        btn.setTextColor(Color.WHITE);
        btn.setPadding(24, 8, 24, 8);
        btn.setBackground(createRoundedBox(bgHex, strokeHex, 20, 2));
        btn.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return btn;
    }

    private Button createFloatingMenuButton() {
        Button btn = new Button(this);
        btn.setText("HUB MENU");
        btn.setTextSize(11);
        btn.setTextColor(Color.WHITE);
        btn.setBackground(createRoundedBox("#CC0F172A", "#38BDF8", 16, 2));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.setMargins(0, 16, 24, 0);
        btn.setLayoutParams(p);
        btn.setOnClickListener(v -> toggleHubOverlay());
        return btn;
    }

    private GradientDrawable createRoundedBox(String bgHex, String borderHex, float radius, int strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(bgHex));
        gd.setCornerRadius(radius);
        if (strokeWidth > 0) {
            gd.setStroke(strokeWidth, Color.parseColor(borderHex));
        }
        return gd;
    }

    private void handleImportZipUri(Uri uri) {
        File extDir = getExternalFilesDir(null);
        if (extDir == null) return;
        File targetDir = new File(extDir, pendingImportTitle.defaultFolderName);
        showImportProgress(true, "Mengekstrak berkas game " + pendingImportTitle.displayName + "...");
        GameFileImporter.extractZipUri(this, uri, targetDir, new GameFileImporter.ProgressListener() {
            @Override
            public void onProgress(int percent, String currentFileName) {
                runOnUiThread(() -> {
                    if (importProgressText != null) {
                        importProgressText.setText("Mengekstrak: " + currentFileName);
                    }
                });
            }

            @Override
            public void onComplete(boolean success, String message) {
                runOnUiThread(() -> {
                    showImportProgress(false, "");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    refreshInstalledGamesStatus();
                });
            }
        });
    }

    private void handleImportFolderUri(Uri uri) {
        File extDir = getExternalFilesDir(null);
        if (extDir == null) return;
        File targetDir = new File(extDir, pendingImportTitle.defaultFolderName);
        showImportProgress(true, "Menyalin folder game " + pendingImportTitle.displayName + "...");
        GameFileImporter.copyFolderUri(this, uri, targetDir, new GameFileImporter.ProgressListener() {
            @Override
            public void onProgress(int percent, String currentFileName) {
                runOnUiThread(() -> {
                    if (importProgressText != null) {
                        importProgressText.setText("Menyalin: " + currentFileName);
                    }
                });
            }

            @Override
            public void onComplete(boolean success, String message) {
                runOnUiThread(() -> {
                    showImportProgress(false, "");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    refreshInstalledGamesStatus();
                });
            }
        });
    }

    private void scanDownloadFolder() {
        List<File> zips = GameFileImporter.scanDownloadFolderForGameZips();
        if (zips.isEmpty()) {
            Toast.makeText(this, "Tidak ada file ZIP Overcooked / Moving Out di folder Download.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] zipNames = new String[zips.size()];
        for (int i = 0; i < zips.size(); i++) {
            zipNames[i] = zips.get(i).getName() + " (" + (zips.get(i).length() / (1024 * 1024)) + " MB)";
        }
        new AlertDialog.Builder(this)
                .setTitle("Pilih File ZIP dari Folder Download")
                .setItems(zipNames, (dialog, which) -> {
                    File selected = zips.get(which);
                    String selName = selected.getName().toLowerCase();
                    if (selName.contains("movingout2") || selName.contains("moving_out_2") || (selName.contains("moving") && selName.contains("2"))) {
                        pendingImportTitle = GameStorageVerifier.GameTitle.MOVING_OUT_2;
                    } else if (selName.contains("moving")) {
                        pendingImportTitle = GameStorageVerifier.GameTitle.MOVING_OUT;
                    } else if (selName.contains("2")) {
                        pendingImportTitle = GameStorageVerifier.GameTitle.OVERCOOKED_2;
                    } else {
                        pendingImportTitle = GameStorageVerifier.GameTitle.OVERCOOKED_1;
                    }
                    handleImportZipUri(Uri.fromFile(selected));
                })
                .show();
    }

    private void showImportProgress(boolean show, String text) {
        if (importProgressBar != null) importProgressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (importProgressText != null) {
            importProgressText.setVisibility(show ? View.VISIBLE : View.GONE);
            importProgressText.setText(text);
        }
    }

    private void showGraphicsSettingsDialog() {
        if (!nativeLoaded) {
            Toast.makeText(this, "Pustaka native belum dimuat", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] options = {
                "Preset: Rendah (Low - SD845 / 30 FPS)",
                "Preset: Sedang (Medium - Seimbang)",
                "Preset: Tinggi (High - Layar Asli HP / 60 FPS)",
                "Preset: Ultra (Flagship MSAA 4x)",
                "Mode Resolusi Layar...",
                "Ringkasan Profil Grafik"
        };
        new AlertDialog.Builder(this)
                .setTitle("Pengaturan Grafik & Resolusi Layar")
                .setItems(options, (dialog, which) -> {
                    try {
                        switch (which) {
                            case 0: nativeSetGraphicsPreset(0); break;
                            case 1: nativeSetGraphicsPreset(1); break;
                            case 2: nativeSetGraphicsPreset(2); break;
                            case 3: nativeSetGraphicsPreset(3); break;
                            case 4: showResolutionModeDialog(); break;
                            case 5:
                                new AlertDialog.Builder(this)
                                        .setTitle("Profil Grafik Aktif")
                                        .setMessage(nativeGetGraphicsSummary())
                                        .setPositiveButton("OK", null)
                                        .show();
                                break;
                        }
                    } catch (Throwable t) {
                        Log.e(TAG, "Gagal mengubah pengaturan grafik: " + t.getMessage());
                    }
                })
                .show();
    }

    private void showResolutionModeDialog() {
        String[] modes = {
                "Resolusi Asli Layar HP (100% Native)",
                "Adaptif (Otomatis sesuai suhu & termal)",
                "Skala 1080p (FHD)",
                "Skala 720p (Hemat Daya)",
                "Skala 540p (Performa Tinggi)"
        };
        new AlertDialog.Builder(this)
                .setTitle("Pilih Mode Resolusi Layar")
                .setItems(modes, (dialog, which) -> {
                    try {
                        nativeSetResolutionMode(which, 1.0f);
                    } catch (Throwable ignored) {}
                })
                .show();
    }

    private void detectAndApplyDeviceDisplaySettings() {
        int width = 1920, height = 1080;
        float dpi = 320.0f, refreshRate = 60.0f;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowMetrics wm = getWindowManager().getCurrentWindowMetrics();
                Rect bounds = wm.getBounds();
                width = bounds.width();
                height = bounds.height();
                Display display = getDisplay();
                if (display != null) refreshRate = display.getRefreshRate();
                dpi = getResources().getDisplayMetrics().densityDpi;
            } else {
                DisplayMetrics metrics = new DisplayMetrics();
                Display display = getWindowManager().getDefaultDisplay();
                display.getRealMetrics(metrics);
                width = metrics.widthPixels;
                height = metrics.heightPixels;
                dpi = metrics.densityDpi;
                refreshRate = display.getRefreshRate();
            }
        } catch (Throwable ignored) {}

        ActivityManager actManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
        long totalRamMb = 4096;
        if (actManager != null) {
            actManager.getMemoryInfo(memInfo);
            totalRamMb = memInfo.totalMem / (1024 * 1024);
        }
        if (nativeLoaded) {
            try {
                nativeInitDisplayInfo(width, height, dpi, refreshRate, (int) totalRamMb);
            } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (engineInitialized && nativeLoaded) {
            try { nativePauseEngine(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (engineInitialized && nativeLoaded) {
            try { nativeResumeEngine(); } catch (Throwable ignored) {}
        }
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (nativeLoaded) {
            try { nativeOnSurfaceCreated(holder.getSurface()); } catch (Throwable ignored) {}
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
        if (nativeLoaded) {
            try { nativeOnSurfaceChanged(width, height); } catch (Throwable ignored) {}
        }
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
        if (nativeLoaded) {
            try { nativeOnSurfaceDestroyed(); } catch (Throwable ignored) {}
        }
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (gamepadManager != null && (event.getSource() & (InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_GAMEPAD)) != 0
                && event.getAction() == MotionEvent.ACTION_MOVE) {
            gamepadManager.processMotionEvent(event);
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (hubOverlayView != null && hubOverlayView.getVisibility() != View.VISIBLE) {
                toggleHubOverlay();
                return true;
            }
            return super.dispatchKeyEvent(event);
        }
        if ((event.getSource() & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_DPAD)) != 0) {
            if (gamepadManager != null) {
                gamepadManager.processKeyEvent(event);
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    public int getJavaThermalStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                try { return pm.getCurrentThermalStatus(); } catch (Throwable ignored) {}
            }
        }
        return 0;
    }

    @Override
    protected void onDestroy() {
        if (gamepadManager != null) gamepadManager.unregister();
        if (engineInitialized && nativeLoaded) {
            try { nativeShutdownEngine(); } catch (Throwable ignored) {}
        }
        super.onDestroy();
    }

    private native void nativeInitEngine(String dataDirPath, int backendOrdinal, int gameVersion);
    private native void nativeInitDisplayInfo(int width, int height, float dpi, float refreshRate, int ramMb);
    private native void nativeSetGraphicsPreset(int presetOrdinal);
    private native void nativeSetResolutionMode(int modeOrdinal, float customScale);
    private native void nativeSetTargetFPS(int fps);
    private native void nativeSetVsync(boolean enabled);
    private native void nativeSetAntiAliasing(int modeOrdinal);
    private native void nativeSetShadowQuality(int qualityOrdinal);
    private native void nativeSetTextureQuality(int qualityOrdinal);
    private native String nativeGetGraphicsSummary();
    private native void nativePauseEngine();
    private native void nativeResumeEngine();
    private native void nativeOnSurfaceCreated(Surface surface);
    private native void nativeOnSurfaceChanged(int width, int height);
    private native void nativeOnSurfaceDestroyed();
    private native void nativeOnGamepadAxis(int deviceId, float lx, float ly, float rx, float ry, float hatX, float hatY);
    private native void nativeOnGamepadButton(int deviceId, int keyCode, boolean pressed);
    private native void nativeShutdownEngine();
}
