package com.overcookedrecomp.app.compiler.core

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream

/**
 * Mengelola dependensi runtime pendukung (.NET / Mono Base Class Libraries,
 * P/Invoke Windows Redistributable Shims, dan konfigurasi translasi DirectX -> Vulkan)
 * di dalam penyimpanan aplikasi Android.
 */
object RuntimeRedistManager {
    private const val TAG = "RuntimeRedistManager"

    val REQUIRED_DOTNET_ASSEMBLIES = listOf(
        "mscorlib.dll",
        "System.dll",
        "System.Core.dll"
    )

    data class RedistStatus(
        val ready: Boolean,
        val dotnetReady: Boolean,
        val shimReady: Boolean,
        val summary: String,
        val redistDir: File
    )

    fun ensureRedistEnvironment(context: Context): RedistStatus {
        val baseDir = context.getExternalFilesDir(null) ?: context.filesDir
        val redistDir = File(baseDir, "runtime_redist")
        val monoBclDir = File(redistDir, "mono_bcl")
        val shimDir = File(redistDir, "win32_shims")

        if (!monoBclDir.exists()) monoBclDir.mkdirs()
        if (!shimDir.exists()) shimDir.mkdirs()

        // Salin file konfigurasi dari APK assets jika tersedia, atau generate langsung
        val vcredistShimFile = File(shimDir, "vcredist_posix_map.cfg")
        if (!vcredistShimFile.exists()) {
            if (!copyAssetIfExists(context, "runtime_redist/win32_shims/vcredist_posix_map.cfg", vcredistShimFile)) {
                writeTextSafe(
                    vcredistShimFile,
                    """
                    # Ghost Town Recomp - Win32 / VCRedist / DirectX Shim Mapping
                    msvcp140.dll=libc++_shared.so
                    vcruntime140.dll=libc++_shared.so
                    ucrtbase.dll=libc.so
                    kernel32.dll=native_posix_shim
                    user32.dll=native_android_window_shim
                    xinput1_3.dll=native_input_mapper
                    xinput1_4.dll=native_input_mapper
                    d3d11.dll=native_vulkan_1_1_bridge
                    dxgi.dll=native_vulkan_swapchain
                    fmodstudio.dll=native_aaudio_mixer
                    """.trimIndent()
                )
            }
        }

        val monoConfigFile = File(monoBclDir, "mono_runtime.config")
        if (!monoConfigFile.exists()) {
            if (!copyAssetIfExists(context, "runtime_redist/mono_bcl/mono_runtime.config", monoConfigFile)) {
                writeTextSafe(
                    monoConfigFile,
                    """
                    <configuration>
                        <dllmap dll="kernel32" target="libovercooked_native.so" />
                        <dllmap dll="user32" target="libovercooked_native.so" />
                        <dllmap dll="xinput1_3" target="libovercooked_native.so" />
                        <dllmap dll="xinput1_4" target="libovercooked_native.so" />
                        <dllmap dll="CSteamworks" target="libovercooked_native.so" />
                        <dllmap dll="steam_api64" target="libovercooked_native.so" />
                    </configuration>
                    """.trimIndent()
                )
            }
        }

        // Sinkronkan assembly .NET BCL (mscorlib.dll, System.dll, System.Core.dll) dari folder game yang terpasang
        syncDotnetAssembliesFromGames(baseDir, monoBclDir)

        val hasDotnetBcl = REQUIRED_DOTNET_ASSEMBLIES.all { File(monoBclDir, it).exists() }
        val shimReady = vcredistShimFile.exists() && monoConfigFile.exists()

        val statusText = when {
            hasDotnetBcl && shimReady -> ".NET/Mono BCL + Win32/Vulkan Redist Siap"
            shimReady -> "Vulkan/Win32 Shim Aktif (.NET BCL otomatis disinkronkan dari Game)"
            else -> "Redist Runtime Belum Lengkap"
        }

        return RedistStatus(
            ready = shimReady,
            dotnetReady = hasDotnetBcl,
            shimReady = shimReady,
            summary = statusText,
            redistDir = redistDir
        )
    }

    fun syncDotnetAssembliesFromGames(baseDir: File, monoBclDir: File) {
        val gameFolders = listOf(
            "Overcooked_Data",
            "Overcooked2_Data",
            "MovingOut_Data",
            "MovingOut2_Data"
        )
        for (folder in gameFolders) {
            val managedDir = File(baseDir, "$folder/Managed")
            if (!managedDir.exists()) continue

            for (dllName in REQUIRED_DOTNET_ASSEMBLIES) {
                val srcDll = File(managedDir, dllName)
                val dstDll = File(monoBclDir, dllName)
                if (srcDll.exists() && !dstDll.exists()) {
                    try {
                        srcDll.copyTo(dstDll, overwrite = false)
                        Log.i(TAG, "Menyalin dependensi .NET BCL $dllName dari $folder")
                    } catch (e: Exception) {
                        Log.w(TAG, "Gagal menyalin $dllName: ${e.message}")
                    }
                }
            }
        }
    }

    private fun copyAssetIfExists(context: Context, assetPath: String, outFile: File): Boolean {
        return try {
            context.assets.open(assetPath).use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun writeTextSafe(file: File, content: String) {
        try {
            FileOutputStream(file).use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menulis berkas redist ${file.name}: ${e.message}")
        }
    }
}
