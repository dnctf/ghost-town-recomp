package com.overcookedrecomp.app.compiler.movingout

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.overcookedrecomp.app.MainActivity
import com.overcookedrecomp.app.compiler.core.VerificationStatus
import java.io.File

class MovingOutLauncherActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DATA_DIR = "EXTRA_DATA_DIR"
        const val EXTRA_GAME_TITLE = "EXTRA_GAME_TITLE"
    }

    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var compileBtn: Button
    private lateinit var launchBtn: Button

    private var gameDataDir: File? = null
    private var compiler: com.overcookedrecomp.app.compiler.core.GameCompiler = MovingOutCompiler()
    private var gameTitleDisplay: String = "Moving Out"
    private var gameIdValue: Int = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val titleExtra = intent.getStringExtra(EXTRA_GAME_TITLE)
        if (titleExtra != null && (titleExtra.contains("2") || titleExtra.contains("II"))) {
            compiler = MovingOut2Compiler()
            gameTitleDisplay = "Moving Out 2"
            gameIdValue = 4
        } else {
            compiler = MovingOutCompiler()
            gameTitleDisplay = "Moving Out"
            gameIdValue = 3
        }

        val dataDirPath = intent.getStringExtra(EXTRA_DATA_DIR)
        gameDataDir = if (dataDirPath != null) File(dataDirPath) else getExternalFilesDir(null)?.let { File(it, compiler.defaultFolderName) }

        setContentView(createLayout())
        refreshStatus()
    }

    private fun createLayout(): View {
        val scrollView = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.parseColor("#0B1220"))
            isFillViewport = true
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 36, 48, 48)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val devBadge = TextView(this).apply {
            text = "GHOST TOWN GAMES / TEAM17 • COMPILER"
            textSize = 12f
            setTextColor(Color.parseColor("#06D6A0"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }
        container.addView(devBadge)

        val titleView = TextView(this).apply {
            text = "$gameTitleDisplay Recomp"
            textSize = 24f
            setTextColor(Color.parseColor("#38BDF8"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(titleView)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createCardDrawable("#162033", "#2A3954")
            setPadding(32, 24, 32, 24)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 20, 0, 20)
            }
        }

        statusText = TextView(this).apply {
            text = "Memeriksa status instalasi..."
            textSize = 13f
            setTextColor(Color.parseColor("#E0E0E0"))
            setPadding(0, 4, 0, 12)
        }
        card.addView(statusText)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            isIndeterminate = true
            visibility = View.GONE
        }
        card.addView(progressBar)
        container.addView(card)

        compileBtn = Button(this).apply {
            text = "Kompilasi & Persiapkan Asset $gameTitleDisplay"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = createButtonDrawable("#0284C7")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8, 0, 12)
            }
            setOnClickListener { runCompilation() }
        }
        container.addView(compileBtn)

        launchBtn = Button(this).apply {
            text = "▶ Mulai $gameTitleDisplay (Vulkan Engine)"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = createButtonDrawable("#06D6A0")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 8, 0, 12)
            }
            setOnClickListener {
                val dir = gameDataDir
                if (dir != null && dir.exists()) {
                    val launchIntent = Intent(this@MovingOutLauncherActivity, MainActivity::class.java).apply {
                        putExtra(MainActivity.EXTRA_AUTO_LAUNCH_GAME_ID, gameIdValue)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    startActivity(launchIntent)
                    finish()
                } else {
                    Toast.makeText(this@MovingOutLauncherActivity, "Data $gameTitleDisplay belum tersedia.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        container.addView(launchBtn)

        val backBtn = Button(this).apply {
            text = "Kembali ke Ghost Town GameHub"
            textSize = 13f
            setTextColor(Color.parseColor("#CBD5E1"))
            background = createButtonDrawable("#1E293B")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnClickListener { finish() }
        }
        container.addView(backBtn)

        scrollView.addView(container)
        return scrollView
    }

    private fun refreshStatus() {
        val baseDir = getExternalFilesDir(null) ?: return
        val status = compiler.verifyInstallation(baseDir)
        when (status) {
            is VerificationStatus.Ready -> {
                statusText.text = "● Status: Siap Dimainkan\nBackend: ${status.backendType}\nLokasi: ${status.targetDir.name}"
                statusText.setTextColor(Color.parseColor("#06D6A0"))
                compileBtn.isEnabled = true
                launchBtn.isEnabled = true
                launchBtn.alpha = 1.0f
            }
            is VerificationStatus.NotInstalled -> {
                statusText.text = "○ Status: Belum Terpasang\nHarap impor folder '${status.expectedFolder}' melalui GameHub."
                statusText.setTextColor(Color.parseColor("#F87171"))
                compileBtn.isEnabled = false
                launchBtn.isEnabled = false
                launchBtn.alpha = 0.5f
            }
            is VerificationStatus.Corrupted -> {
                statusText.text = "⚠ Status: Berkas Tidak Lengkap\n${status.message}"
                statusText.setTextColor(Color.parseColor("#FFD166"))
                compileBtn.isEnabled = false
                launchBtn.isEnabled = false
                launchBtn.alpha = 0.5f
            }
        }
    }

    private fun runCompilation() {
        val dir = gameDataDir ?: return
        progressBar.visibility = View.VISIBLE
        compileBtn.isEnabled = false
        Thread {
            compiler.compileAndPrepare(this, dir) { msg ->
                runOnUiThread { statusText.text = msg }
            }
            runOnUiThread {
                progressBar.visibility = View.GONE
                compileBtn.isEnabled = true
                Toast.makeText(this, "Kompilasi asset $gameTitleDisplay selesai!", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }.start()
    }

    private fun createButtonDrawable(hexColor: String): GradientDrawable =
        GradientDrawable().apply { setColor(Color.parseColor(hexColor)); cornerRadius = 14f }

    private fun createCardDrawable(bgHex: String, borderHex: String): GradientDrawable =
        GradientDrawable().apply { setColor(Color.parseColor(bgHex)); cornerRadius = 18f; setStroke(2, Color.parseColor(borderHex)) }
}
