#include "native_engine.h"
#include "graphics_settings.h"
#include <jni.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <chrono>
#include <cmath>
#include <thread>
#include <algorithm>

#define LOG_TAG "OvercookedNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace overcooked {

NativeEngine::NativeEngine() {
    arena_ = std::make_unique<LinearMemoryArena>(32ULL * 1024ULL * 1024ULL);
}

NativeEngine& NativeEngine::Instance() {
    static NativeEngine instance;
    return instance;
}

void NativeEngine::Initialize(const std::string& data_dir, int backend_ordinal, int game_version) {
    data_dir_ = data_dir;
    backend_ordinal_ = backend_ordinal;
    if (!arena_) {
        arena_ = std::make_unique<LinearMemoryArena>(32ULL * 1024ULL * 1024ULL);
    }
    thermal_.Initialize();
    audio_.Initialize(48000, 2);
    bool rt_ok = runtime_host_.Initialize(data_dir_, backend_ordinal_, game_version);
    LOGI("NativeEngine diinisialisasi untuk %s (versi %d, runtime_ok=%d, redist=%d) di: %s",
         runtime_host_.GetGameTitleName(), game_version, rt_ok ? 1 : 0,
         runtime_host_.IsRedistVerified() ? 1 : 0, data_dir_.c_str());
}

void NativeEngine::InitDisplayInfo(uint32_t width, uint32_t height, float dpi, float refresh_rate, uint32_t ram_mb) {
    uint32_t adreno_series = vulkan_.DeviceCaps().adreno_series;
    GraphicsSettingsManager::Instance().Initialize(width, height, dpi, refresh_rate, adreno_series, ram_mb);
}

void NativeEngine::OnSurfaceCreated(ANativeWindow* window) {
    if (render_thread_.joinable()) {
        running_.store(false);
        render_thread_.join();
    }
    window_ = window;
    if (vulkan_.Initialize(window_)) {
        running_.store(true);
        paused_.store(false);
        render_thread_ = std::thread(&NativeEngine::RenderLoop, this);
    }
}

void NativeEngine::OnSurfaceChanged(uint32_t width, uint32_t height) {
    vulkan_.Resize(width, height);
}

void NativeEngine::OnSurfaceDestroyed() {
    running_.store(false);
    if (render_thread_.joinable()) {
        render_thread_.join();
    }
    vulkan_.Shutdown();
    if (window_) {
        ANativeWindow_release(window_);
        window_ = nullptr;
    }
}

void NativeEngine::Pause() {
    paused_.store(true);
}

void NativeEngine::Resume() {
    paused_.store(false);
}

void NativeEngine::RenderLoop() {
    float phase = 0.0f;
    constexpr float kTwoPi = 6.28318530718f;
    while (running_.load()) {
        if (paused_.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        auto frame_start = std::chrono::steady_clock::now();

        RenderBudgetConfig budget = thermal_.EvaluatePolicy();
        auto& gfx = GraphicsSettingsManager::Instance();
        const auto& gfx_cfg = gfx.GetConfig();

        uint32_t target_fps = std::min(gfx_cfg.target_fps, budget.target_fps);
        if (target_fps == 0) target_fps = 30;

        runtime_host_.TickFrame(1.0f / static_cast<float>(target_fps));

        PlayerInputState p0 = input_mapper_.GetPlayerState(0);
        float input_boost = (std::fabs(p0.move_x) + std::fabs(p0.move_y)) * 0.06f;

        phase = std::fmod(phase + 0.025f + input_boost, kTwoPi);

        // Warna tema dinamis Vulkan per-game untuk verifikasi visual runtime aktif
        float r = 0.12f, g = 0.16f, b = 0.24f;
        switch (runtime_host_.GetGameTitle()) {
            case GameTitle::OVERCOOKED_1:
                r = 0.88f + 0.07f * std::sin(phase);
                g = 0.45f + 0.07f * std::cos(phase);
                b = 0.12f;
                break;
            case GameTitle::OVERCOOKED_2:
                r = 0.85f + 0.08f * std::sin(phase);
                g = 0.16f + 0.05f * std::cos(phase);
                b = 0.24f;
                break;
            case GameTitle::MOVING_OUT:
                r = 0.06f;
                g = 0.58f + 0.08f * std::sin(phase);
                b = 0.86f + 0.08f * std::cos(phase);
                break;
            case GameTitle::MOVING_OUT_2:
                r = 0.05f;
                g = 0.74f + 0.08f * std::sin(phase);
                b = 0.56f + 0.08f * std::cos(phase);
                break;
            default:
                r = 0.10f + 0.03f * std::sin(phase);
                g = 0.15f + 0.03f * std::cos(phase);
                b = 0.25f;
                break;
        }

        if (p0.action_pickup_drop || p0.action_chop || p0.action_throw) {
            r = std::min(1.0f, r + 0.12f);
            g = std::min(1.0f, g + 0.12f);
            b = std::min(1.0f, b + 0.12f);
        }

        float active_scale = std::clamp(budget.resolution_scale * gfx_cfg.custom_resolution_scale, 0.4f, 1.25f);
        vulkan_.RenderClearFrame(r, g, b, active_scale);

        if (arena_) {
            arena_->ResetFrameScratch();
        }

        auto target_duration = std::chrono::microseconds(1000000 / target_fps);
        auto elapsed = std::chrono::steady_clock::now() - frame_start;
        if (elapsed < target_duration) {
            auto remaining = std::chrono::duration_cast<std::chrono::microseconds>(target_duration - elapsed);
            if (remaining.count() > budget.spin_wait_sleep_us) {
                std::this_thread::sleep_for(remaining - std::chrono::microseconds(budget.spin_wait_sleep_us));
            }
            while (std::chrono::steady_clock::now() - frame_start < target_duration) {
                std::this_thread::yield();
            }
        }
    }
}

void NativeEngine::Shutdown() {
    OnSurfaceDestroyed();
    audio_.Shutdown();
    runtime_host_.Shutdown();
}

} // namespace overcooked

extern "C" {

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeInitEngine(
        JNIEnv* env, jobject /*thiz*/, jstring data_dir, jint backend_ordinal, jint game_version) {
    const char* raw_path = env->GetStringUTFChars(data_dir, nullptr);
    std::string path(raw_path ? raw_path : "");
    if (raw_path) env->ReleaseStringUTFChars(data_dir, raw_path);
    overcooked::NativeEngine::Instance().Initialize(path, backend_ordinal, game_version);
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeInitDisplayInfo(
        JNIEnv* /*env*/, jobject /*thiz*/,
        jint width, jint height, jfloat dpi, jfloat refresh_rate, jint ram_mb) {
    overcooked::NativeEngine::Instance().InitDisplayInfo(
        static_cast<uint32_t>(width),
        static_cast<uint32_t>(height),
        dpi,
        refresh_rate,
        static_cast<uint32_t>(ram_mb)
    );
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetGraphicsPreset(
        JNIEnv* /*env*/, jobject /*thiz*/, jint preset_ordinal) {
    overcooked::GraphicsSettingsManager::Instance().ApplyPreset(
        static_cast<overcooked::GraphicsPreset>(preset_ordinal)
    );
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetResolutionMode(
        JNIEnv* /*env*/, jobject /*thiz*/, jint mode_ordinal, jfloat custom_scale) {
    auto& mgr = overcooked::GraphicsSettingsManager::Instance();
    mgr.SetResolutionMode(static_cast<overcooked::ResolutionMode>(mode_ordinal));
    if (custom_scale > 0.0f) {
        mgr.SetCustomResolutionScale(custom_scale);
    }
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetTargetFPS(
        JNIEnv* /*env*/, jobject /*thiz*/, jint fps) {
    overcooked::GraphicsSettingsManager::Instance().SetTargetFPS(static_cast<uint32_t>(fps));
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetVsync(
        JNIEnv* /*env*/, jobject /*thiz*/, jboolean enabled) {
    overcooked::GraphicsSettingsManager::Instance().SetVsync(enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetAntiAliasing(
        JNIEnv* /*env*/, jobject /*thiz*/, jint mode_ordinal) {
    overcooked::GraphicsSettingsManager::Instance().SetAntiAliasing(
        static_cast<overcooked::AntiAliasingMode>(mode_ordinal)
    );
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetShadowQuality(
        JNIEnv* /*env*/, jobject /*thiz*/, jint quality_ordinal) {
    overcooked::GraphicsSettingsManager::Instance().SetShadowQuality(
        static_cast<overcooked::ShadowQuality>(quality_ordinal)
    );
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeSetTextureQuality(
        JNIEnv* /*env*/, jobject /*thiz*/, jint quality_ordinal) {
    overcooked::GraphicsSettingsManager::Instance().SetTextureQuality(
        static_cast<overcooked::TextureQuality>(quality_ordinal)
    );
}

JNIEXPORT jstring JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeGetGraphicsSummary(
        JNIEnv* env, jobject /*thiz*/) {
    std::string summary = overcooked::GraphicsSettingsManager::Instance().GetSummaryString();
    return env->NewStringUTF(summary.c_str());
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativePauseEngine(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    overcooked::NativeEngine::Instance().Pause();
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeResumeEngine(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    overcooked::NativeEngine::Instance().Resume();
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeOnSurfaceCreated(
        JNIEnv* env, jobject /*thiz*/, jobject surface) {
    ANativeWindow* window = ANativeWindow_fromSurface(env, surface);
    overcooked::NativeEngine::Instance().OnSurfaceCreated(window);
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeOnSurfaceChanged(
        JNIEnv* /*env*/, jobject /*thiz*/, jint width, jint height) {
    overcooked::NativeEngine::Instance().OnSurfaceChanged(
        static_cast<uint32_t>(width), static_cast<uint32_t>(height));
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeOnSurfaceDestroyed(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    overcooked::NativeEngine::Instance().OnSurfaceDestroyed();
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeOnGamepadAxis(
        JNIEnv* /*env*/, jobject /*thiz*/, jint device_id,
        jfloat lx, jfloat ly, jfloat rx, jfloat ry, jfloat hat_x, jfloat hat_y) {
    overcooked::NativeEngine::Instance().GetInputMapper().UpdateAxis(
        device_id, lx, ly, rx, ry, hat_x, hat_y);
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeOnGamepadButton(
        JNIEnv* /*env*/, jobject /*thiz*/, jint device_id, jint key_code, jboolean pressed) {
    overcooked::NativeEngine::Instance().GetInputMapper().UpdateButton(
        device_id, key_code, pressed == JNI_TRUE);
}

JNIEXPORT void JNICALL Java_com_overcookedrecomp_app_MainActivity_nativeShutdownEngine(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    overcooked::NativeEngine::Instance().Shutdown();
}

} // extern "C"
