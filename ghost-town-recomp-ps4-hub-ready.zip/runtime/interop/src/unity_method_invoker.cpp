#include "unity_shim.h"
#include <android/log.h>
#include <fstream>
#include <unordered_map>
#include <mutex>

#define LOG_TAG "UnityInteropShim"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace overcooked {

namespace {
std::unordered_map<int32_t, NativeTransform> g_transforms;
std::mutex g_transform_mutex;
} // namespace

bool UnityRuntimeHost::VerifyRedistDependencies(const std::string& data_dir) {
    size_t slash = data_dir.find_last_of('/');
    std::string base_dir = (slash != std::string::npos) ? data_dir.substr(0, slash) : data_dir;
    std::string shim_cfg = base_dir + "/runtime_redist/win32_shims/vcredist_posix_map.cfg";

    std::ifstream f(shim_cfg);
    if (f.is_open()) {
        LOGI("Win32/VCRedist/Vulkan Shim terverifikasi di: %s", shim_cfg.c_str());
        return true;
    }
    LOGW("File shim redist belum ditemukan di %s, menggunakan fallback internal.", shim_cfg.c_str());
    return false;
}

bool UnityRuntimeHost::Initialize(const std::string& data_dir, int backend_ordinal, int game_version) {
    active_backend_ = backend_ordinal;
    game_title_ = static_cast<GameTitle>(game_version);
    redist_verified_ = VerifyRedistDependencies(data_dir);

    if (backend_ordinal == 1) { // MONO_CIL
        return mono_host_.Initialize(data_dir + "/Managed", data_dir + "/Managed/Assembly-CSharp.dll");
    } else if (backend_ordinal == 2) { // IL2CPP_AOT
        return il2cpp_loader_.LoadFromFile(data_dir + "/il2cpp_data/Metadata/global-metadata.dat");
    }
    return false;
}

const char* UnityRuntimeHost::GetGameTitleName() const {
    switch (game_title_) {
        case GameTitle::OVERCOOKED_1: return "Overcooked!";
        case GameTitle::OVERCOOKED_2: return "Overcooked! 2";
        case GameTitle::MOVING_OUT:   return "Moving Out";
        case GameTitle::MOVING_OUT_2: return "Moving Out 2";
        default: return "Unknown Game";
    }
}

void UnityRuntimeHost::TickFrame(float delta_time) {
    if (active_backend_ == 1) {
        mono_host_.TickUpdate(delta_time);
    }
}

void UnityRuntimeHost::Shutdown() {
    mono_host_.Shutdown();
}

void UnityRuntimeHost::SetTransformPosition(int32_t handle, const Vector3& pos) {
    std::lock_guard<std::mutex> lock(g_transform_mutex);
    auto& tf = g_transforms[handle];
    tf.position = pos;
    tf.dirty = true;
}

Vector3 UnityRuntimeHost::GetTransformPosition(int32_t handle) {
    std::lock_guard<std::mutex> lock(g_transform_mutex);
    auto it = g_transforms.find(handle);
    return (it != g_transforms.end()) ? it->second.position : Vector3{0.0f, 0.0f, 0.0f};
}

} // namespace overcooked
