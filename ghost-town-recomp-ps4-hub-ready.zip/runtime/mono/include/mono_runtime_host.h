#pragma once

#include <string>

namespace overcooked {

class MonoRuntimeHost {
public:
    bool Initialize(const std::string& managed_dir, const std::string& assembly_path);
    void TickUpdate(float delta_time);
    void Shutdown();
    bool HasDotnetBcl() const { return has_dotnet_bcl_; }

private:
    bool ValidatePeHeader(const std::string& dll_path) const;

    bool initialized_ = false;
    bool has_dotnet_bcl_ = false;
    std::string assembly_path_;
    std::string bcl_dir_;
};

} // namespace overcooked
