#include "mono_runtime_host.h"
#include <android/log.h>
#include <fstream>
#include <vector>

#define LOG_TAG "OvercookedMono"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace overcooked {

bool MonoRuntimeHost::ValidatePeHeader(const std::string& dll_path) const {
    std::ifstream dll(dll_path, std::ios::binary);
    if (!dll.is_open()) {
        return false;
    }
    uint16_t dos_magic = 0;
    dll.read(reinterpret_cast<char*>(&dos_magic), sizeof(dos_magic));
    return dos_magic == 0x5A4D; // 'MZ'
}

bool MonoRuntimeHost::Initialize(const std::string& managed_dir, const std::string& assembly_path) {
    assembly_path_ = assembly_path;
    if (!ValidatePeHeader(assembly_path_)) {
        LOGE("Assembly-CSharp.dll tidak ditemukan atau header PE tidak valid di: %s", assembly_path_.c_str());
        return false;
    }

    // Cari pustaka .NET BCL (mscorlib.dll, System.dll, System.Core.dll) di Managed/ atau runtime_redist/mono_bcl/
    std::string shared_bcl_dir;
    size_t data_pos = managed_dir.find_last_of('/');
    if (data_pos != std::string::npos) {
        std::string game_dir = managed_dir.substr(0, data_pos);
        size_t base_pos = game_dir.find_last_of('/');
        if (base_pos != std::string::npos) {
            shared_bcl_dir = game_dir.substr(0, base_pos) + "/runtime_redist/mono_bcl";
        }
    }

    const std::vector<std::string> bcl_libs = { "mscorlib.dll", "System.dll", "System.Core.dll" };
    int found_count = 0;
    for (const auto& lib : bcl_libs) {
        if (ValidatePeHeader(managed_dir + "/" + lib)) {
            found_count++;
            bcl_dir_ = managed_dir;
        } else if (!shared_bcl_dir.empty() && ValidatePeHeader(shared_bcl_dir + "/" + lib)) {
            found_count++;
            bcl_dir_ = shared_bcl_dir;
        }
    }

    has_dotnet_bcl_ = (found_count == static_cast<int>(bcl_libs.size()));
    if (has_dotnet_bcl_) {
        LOGI(".NET/Mono BCL lengkap (%d/%zu DLL) dimuat dari: %s", found_count, bcl_libs.size(), bcl_dir_.c_str());
    } else {
        LOGW(".NET/Mono BCL parsial (%d/%zu DLL). Pastikan folder Managed/ berisi mscorlib.dll & System.dll.", found_count, bcl_libs.size());
    }

    initialized_ = true;
    LOGI("MonoRuntimeHost siap memuat bytecode CIL dari %s", assembly_path_.c_str());
    return true;
}

void MonoRuntimeHost::TickUpdate(float /*delta_time*/) {
    if (!initialized_) return;
    // Domain Mono aktif; sinkronisasi MonoBehaviour frame tick
}

void MonoRuntimeHost::Shutdown() {
    initialized_ = false;
    has_dotnet_bcl_ = false;
}

} // namespace overcooked
